package com.infy.ekart.dao;

import java.util.List;

import com.infy.ekart.model.Wishlist;
import com.infy.ekart.model.Product;

public interface WishlistDAO {

	public void addProductToWishlist(String customerEmailId, Wishlist wishlist);
	public List<Wishlist> getCustomerWishlist(String customerEmailId);
//	public void modifyQuantityOfProductInWishlist(Integer wishlistId, Integer quantity);
	public void deleteProductFromWishlist(String customerEmailId, Integer wishlistId);
	public Product getProductById(Integer productId);
}
