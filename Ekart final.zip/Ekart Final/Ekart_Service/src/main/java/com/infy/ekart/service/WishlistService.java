package com.infy.ekart.service;

import java.util.List;

//import com.infy.ekart.model.CustomerCart;
import com.infy.ekart.model.Wishlist;

public interface WishlistService {
	
	public void addProductToWishlist(String customerEmailId, Wishlist wishlist) throws Exception;
	public List<Wishlist> getCustomerWishlist(String customerEmailId) throws Exception;
//	public void modifyQuantityOfProductInCart(Integer cartId, Integer quantity, Integer productId) throws Exception;
	public void deleteProductFromWishlist(String customerEmailId, Integer wishlistId);
}
