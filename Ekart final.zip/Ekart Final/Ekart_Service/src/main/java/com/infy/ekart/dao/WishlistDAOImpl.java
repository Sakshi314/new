package com.infy.ekart.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

//import com.infy.ekart.entity.CustomerCartEntity;
import com.infy.ekart.entity.CustomerEntity;
import com.infy.ekart.entity.ProductEntity;
import com.infy.ekart.entity.WishlistEntity;
//import com.infy.ekart.model.CustomerCart;
import com.infy.ekart.model.Product;
import com.infy.ekart.model.Wishlist;

@Repository(value = "WishlistDAO")
public class WishlistDAOImpl implements WishlistDAO {

	@Autowired
	private EntityManager entityManager;
	
	@Override
	public void addProductToWishlist(String customerEmailId, Wishlist wishlist) {

		WishlistEntity wishlistEntity = new WishlistEntity();
		
		ProductEntity productEntity = entityManager.find(ProductEntity.class, wishlist.getProduct().getProductId());
		
		wishlistEntity.setProductEntity(productEntity);
//		cartEntity.setQuantity(customerCart.getQuantity());
		
		CustomerEntity customerEntity = entityManager.find(CustomerEntity.class, customerEmailId);
		customerEntity.getWishlist().add(wishlistEntity);
		
		entityManager.persist(customerEntity);
	}

	@Override
	public List<Wishlist> getCustomerWishlist(String customerEmailId) {
		
		CustomerEntity customerEntity = entityManager.find(CustomerEntity.class, customerEmailId);
		List<WishlistEntity> wishlistEntities = customerEntity.getWishlist(); 
		
		List<Wishlist> listWishlist = new ArrayList<>();
		for (WishlistEntity wishlistEntity : wishlistEntities) {
			Wishlist wishlist = new Wishlist();
			wishlist.setWishlistId(wishlistEntity.getWishlistId());
//			wishlist.setQuantity(customerCartEntity.getQuantity());
			ProductEntity productEntity = wishlistEntity.getProductEntity();
			
			Product product = new Product();
			product.setBrand(productEntity.getBrand());
			product.setCategory(productEntity.getCategory());
			product.setDescription(productEntity.getDescription());
			product.setDiscount(productEntity.getDiscount());
			product.setName(productEntity.getName());
			product.setPrice(productEntity.getPrice());
			product.setProductId(productEntity.getProductId());
			product.setQuantity(productEntity.getQuantity());
			
			wishlist.setProduct(product);
			
			listWishlist.add(wishlist);
		}
		return listWishlist;
	}

//	@Override
//	public void modifyQuantityOfProductInCart(Integer cartId, Integer quantity) {
//		
//		CustomerCartEntity cartEntity = entityManager.find(CustomerCartEntity.class, cartId);
//		
//		cartEntity.setQuantity(quantity);
//		
//	}

	@Override
	public void deleteProductFromWishlist(String customerEmailId, Integer wishlistId) {

		CustomerEntity customerEntity = entityManager.find(CustomerEntity.class, customerEmailId);
		List<WishlistEntity> wishlist = customerEntity.getWishlist();
		WishlistEntity wishlistToRemove = null;
		
		for (WishlistEntity wishlistEntity : wishlist) {
			if(wishlistId.equals(wishlistEntity.getWishlistId()))
			{
				wishlistToRemove = wishlistEntity;
			}
		}
		wishlist.remove(wishlistToRemove);
		
		WishlistEntity wishlistEntity = entityManager.find(WishlistEntity.class, wishlistId);
		
		entityManager.remove(wishlistEntity);
		
	}
	
	@Override
	public Product getProductById(Integer productId) {
		
		Product product =null;
		ProductEntity productEntity = entityManager.find(ProductEntity.class, productId);
		
		if (productEntity!=null){
			product = new Product();
			product.setBrand(productEntity.getBrand());
			product.setCategory(productEntity.getCategory());
			product.setDescription(productEntity.getDescription());
			product.setDiscount(productEntity.getDiscount());
			product.setName(productEntity.getName());
			product.setPrice(productEntity.getPrice());
			product.setProductId(productEntity.getProductId());
			product.setQuantity(productEntity.getQuantity());
			
		}
		return product;
	}

}
