package com.infy.ekart.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

//import com.infy.ekart.model.CustomerCart;
import com.infy.ekart.model.Wishlist;
//import com.infy.ekart.service.CustomerCartService;
import com.infy.ekart.service.WishlistService;


@CrossOrigin
@RestController
@RequestMapping("WishlistAPI")
public class WishlistAPI {

	@Autowired
	private WishlistService wishlistService;
	@Autowired
	private Environment environment;
	
	@PostMapping(value = "addProductToWishlist/{customerEmailId:.+}")
	public ResponseEntity<String> addProductToWishlist(@RequestBody Wishlist wishlist, @PathVariable("customerEmailId") String customerEmailId) throws Exception {
		try
		{
			wishlistService.addProductToWishlist(customerEmailId, wishlist);
			
			String message = environment.getProperty("WishlistAPI.PRODUCT_ADDED_TO_WISHLIST");
			
			return new ResponseEntity<String>(message, HttpStatus.OK);
			
		}
		catch (Exception e) {
			
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, environment.getProperty(e.getMessage()));
		}
	}
	
	
	
	@GetMapping(value = "getCustomerWishlist/{customerEmailId:.+}/")
	public ResponseEntity<List<Wishlist>> getCustomerWishlist(@PathVariable("customerEmailId") String customerEmailId) throws Exception{
	List<Wishlist> list = null;	
		try
		{
			
			list = wishlistService.getCustomerWishlist(customerEmailId);
			ResponseEntity<List<Wishlist>> response=new ResponseEntity<List<Wishlist>>(list, HttpStatus.OK);
			return response;
		}
		catch (Exception e) {

			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, environment.getProperty(e.getMessage()));
		}
	}
	
	
	
//	@PostMapping(value = "modifyQuantityOfProductInCart")
//	public ResponseEntity<String> modifyQuantityOfProductInCart(@RequestBody CustomerCart customerCart) throws Exception{
//		
//		try
//		{
//			customerCartService.modifyQuantityOfProductInCart(customerCart.getCartId(), customerCart.getQuantity(), customerCart.getProduct().getProductId());;
//			
//			String message = environment.getProperty("CustomerCartAPI.QUANTITY_UPDATE_SUCCESS");
//			
//			return new ResponseEntity<String>(message, HttpStatus.OK);
//		}
//        catch (Exception e) {
//			
//			throw new ResponseStatusException(HttpStatus.PRECONDITION_FAILED, environment.getProperty(e.getMessage()));
//		}
//	}
	
	
	
	@PostMapping(value = "deleteProductFromWishlist/{customerEmailId:.+}")
	public ResponseEntity<String> deleteProductFromWishlist(@PathVariable("customerEmailId") String customerEmailId, @RequestBody String wishlistId) throws Exception{
		
		try
		{
			wishlistService.deleteProductFromWishlist(customerEmailId, Integer.parseInt(wishlistId));
			
			String message = environment.getProperty("WishlistAPI.PRODUCT_DELETED_FROM_CART_SUCCESS");
			
			return new ResponseEntity<String>(message, HttpStatus.OK);
		}
		catch (Exception e) {
			
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, environment.getProperty(e.getMessage()));
		}
	}
}
