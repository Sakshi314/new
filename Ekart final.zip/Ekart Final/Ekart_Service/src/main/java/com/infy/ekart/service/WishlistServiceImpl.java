package com.infy.ekart.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

//import com.infy.ekart.dao.CustomerCartDAO;
import com.infy.ekart.dao.WishlistDAO;
//import com.infy.ekart.model.CustomerCart;
//import com.infy.ekart.model.Product;
import com.infy.ekart.model.Wishlist;

@Service(value = "wishlistService")
@Transactional
public class WishlistServiceImpl implements WishlistService {

	@Autowired
	private WishlistDAO wishlistDAO;
	
	@Override
	public void addProductToWishlist(String customerEmailId, Wishlist wishlist) throws Exception {

		List<Wishlist> wishlistsFromDB = wishlistDAO.getCustomerWishlist(customerEmailId);
		
		for (Wishlist wishlistFromDB : wishlistsFromDB) {

			if(wishlistFromDB.getProduct().getProductId().equals(wishlist.getProduct().getProductId()))
				throw new Exception("WishlistService.PRODUCT_PRESENT_IN_CART");
		}
		
//		Product productFromDao = wishlistDAO.getProductById(wishlist.getProduct().getProductId());
//		if(productFromDao.getQuantity() < wishlist.getQuantity())
//			throw new Exception("CustomerCartService.INSUFFICIENT_STOCK");
		
		wishlistDAO.addProductToWishlist(customerEmailId, wishlist);

	}




	@Override
	public List<Wishlist> getCustomerWishlist(String customerEmailId) throws Exception {

		List<Wishlist> wishlistsFromDB = wishlistDAO.getCustomerWishlist(customerEmailId);
		if(wishlistsFromDB==null || wishlistsFromDB.isEmpty())
		{
			throw new Exception("WishlistService.NO_PRODUCT_ADDED_TO_CART");
		}

		return wishlistsFromDB;
	}




//	@Override
//	public void modifyQuantityOfProductInCart(Integer cartId, Integer quantity, Integer productId) throws Exception {
//
//		Product productFromDB  = customerCartDAO.getProductById(productId);
//		if(quantity>productFromDB.getQuantity())
//			throw new Exception("CustomerCartService.INSUFFICIENT_STOCK");
//		
//		customerCartDAO.modifyQuantityOfProductInCart(cartId, quantity);
//
//	}





	@Override
	public void deleteProductFromWishlist(String customerEmailId, Integer wishlistId) {
		wishlistDAO.deleteProductFromWishlist(customerEmailId, wishlistId);
	}

}
