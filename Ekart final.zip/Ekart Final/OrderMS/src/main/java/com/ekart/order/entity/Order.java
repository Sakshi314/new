package com.ekart.order.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ekart.order.dto.OrderDTO;

@Entity
@Table(name = "ekartorder")
public class Order {

	@Id
	@Column(name = "order_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int orderId;
	
	@Column(name = "buyer_id")
	int buyerId;
	
	@Column(name = "buyer_email")
	String buyerEmail;
	
	public Order(int orderId, int buyerId, String buyerEmail, LocalDate orderDate, LocalDate estimatedDeliverDate,
			LocalDate deliverDate, int productId, int sellerId, int quantity, String address, long cardNo,
			String status) {
		super();
		this.orderId = orderId;
		this.buyerId = buyerId;
		this.buyerEmail = buyerEmail;
		this.orderDate = orderDate;
		this.estimatedDeliverDate = estimatedDeliverDate;
		this.deliverDate = deliverDate;
		this.productId = productId;
		this.sellerId = sellerId;
		this.quantity = quantity;
		this.address = address;
		this.cardNo = cardNo;
		this.status = status;
	}

	public String getBuyerEmail() {
		return buyerEmail;
	}

	public void setBuyerEmail(String buyerEmail) {
		this.buyerEmail = buyerEmail;
	}

	@Column(name = "order_date")
	LocalDate orderDate;
	
	@Column(name = "estimated_deliver_date")
	LocalDate estimatedDeliverDate;
	
	@Column(name = "deliver_date")
	LocalDate deliverDate;
	
	@Column(name = "product_id")
	int productId;
	
	@Column(name = "seller_id")
	int sellerId;
	
	@Column(name = "quantity")
	int quantity;
	
	@Column(name = "address")
	String address;
	
	@Column(name = "card_no")
	long cardNo;
	
	@Column(name = "status")
	String status;
	
	
	public Order() {
		super();
	}

	public Order(int orderId, int buyerId, LocalDate orderDate, LocalDate estimatedDeliverDate, LocalDate deliverDate, int productId,
			int sellerId, int quantity, String address, long cardNo, String status) {
		super();
		this.orderId = orderId;
		this.buyerId = buyerId;
		this.orderDate = orderDate;
		this.estimatedDeliverDate = estimatedDeliverDate;
		this.deliverDate = deliverDate;
		this.productId = productId;
		this.sellerId = sellerId;
		this.quantity = quantity;
		this.address = address;
		this.cardNo = cardNo;
		this.status = status;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getBuyerId() {
		return buyerId;
	}

	public void setBuyerId(int buyerId) {
		this.buyerId = buyerId;
	}

	public LocalDate getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}

	public LocalDate getEstimatedDeliverDate() {
		return estimatedDeliverDate;
	}

	public void setEstimatedDeliverDate(LocalDate estimatedDeliverDate) {
		this.estimatedDeliverDate = estimatedDeliverDate;
	}

	public LocalDate getDeliverDate() {
		return deliverDate;
	}

	public void setDeliverDate(LocalDate deliverDate) {
		this.deliverDate = deliverDate;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}
	
	public int getSellerId() {
		return sellerId;
	}
	
	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	public String getAddress() {
		return address;
	}
	
	public void setAddress(String address) {
		this.address = address;
	}
	
	public long getCardNo() {
		return cardNo;
	}
	
	public void setCardNo(long cardNo) {
		this.cardNo = cardNo;
	}
	
	public String getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}
	
	public static Order prepareOrderEntity(OrderDTO orderDTO) {
		return new Order(orderDTO.getOrderId(), orderDTO.getBuyerId(), orderDTO.getBuyerEmail(), orderDTO.getOrderDate(), orderDTO.getEstimatedDeliverDate(),
				orderDTO.getDeliverDate(), orderDTO.getProductId(), orderDTO.getSellerId(),
				orderDTO.getQuantity(), orderDTO.getAddress(), orderDTO.getCardNo(),
				orderDTO.getStatus());
	}
}
