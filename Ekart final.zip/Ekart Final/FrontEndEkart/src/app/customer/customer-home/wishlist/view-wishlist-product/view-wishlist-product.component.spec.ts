import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewWishlistProductComponent } from './view-wishlist-product.component';

describe('ViewWishlistProductComponent', () => {
  let component: ViewWishlistProductComponent;
  let fixture: ComponentFixture<ViewWishlistProductComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewWishlistProductComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewWishlistProductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
