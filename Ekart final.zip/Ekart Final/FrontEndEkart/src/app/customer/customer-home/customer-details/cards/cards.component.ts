import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from 'src/app/shared/models/customer';
import { Card } from '../add-card/Card';

@Component({
  selector: 'app-cards',
  templateUrl: './cards.component.html',
  styleUrls: ['./cards.component.css']
})
export class CardsComponent implements OnInit {

  cards!: Card[];
  constructor(private router: Router, private http: HttpClient) { }
  loggedInCustomer: Customer;

  ngOnInit(): void {
    this.loggedInCustomer = JSON.parse(sessionStorage.getItem("customer"));
    this.viewCards();
  }

  addNewCard() {
    this.router.navigate(['./cards']);
  }

  deleteCard(cardNumber: number) {
    this.http
      .delete<any>(`http://localhost:9111/cardInfo/delete?customerEmail=${this.loggedInCustomer.emailId}&cardNumber=${cardNumber}`)
      .subscribe((result) => {
        console.log(result);
      });
    setTimeout(() => { this.viewCards() }, 1000 * 1);
  }

  viewCards() {
    this.http.get<any>(`http://localhost:9111/cardInfo/view?customerEmail=${this.loggedInCustomer.emailId}`).subscribe((result) => {
      console.log(result);
      this.cards = JSON.parse(JSON.stringify(result));
    });
  }

}
