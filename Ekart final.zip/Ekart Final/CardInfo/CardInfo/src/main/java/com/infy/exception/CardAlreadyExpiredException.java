package com.infy.exception;

public class CardAlreadyExpiredException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public CardAlreadyExpiredException(String message) {
		super(message);
	}
}
