package com.infy.repo;

import java.util.List;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.infy.entity.CardInfo;

public interface CardInfoRepo extends JpaRepository<CardInfo, Integer> {

	List<CardInfo> findByCustomerEmail(String customerEmail);

	@Transactional
	void deleteByCustomerEmailAndCardNumber(String customerEmail, Long cardNumber);

}
