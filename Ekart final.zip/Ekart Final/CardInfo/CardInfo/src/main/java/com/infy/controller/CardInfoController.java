package com.infy.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.infy.dto.CardInfoDTO;
import com.infy.exception.CardAlreadyExpiredException;
import com.infy.exception.CardNumberNotUniqueException;
import com.infy.exception.InvalidCardNumberException;
import com.infy.service.CardInfoService;

@RestController
@RequestMapping("cardInfo")
public class CardInfoController {

	@Autowired
	CardInfoService cardInfoService;

	@PostMapping("add")
	public ResponseEntity<Object> add(@RequestBody CardInfoDTO cardInfoDTO) {
		cardInfoService.add(cardInfoDTO);
		return new ResponseEntity<>(HttpStatus.OK);
	}

	@GetMapping("view")
	public ResponseEntity<Object> view(@RequestParam("customerEmail") String customerEmail) {
		List<CardInfoDTO> cardInfoDTOs = cardInfoService.view(customerEmail);
		return new ResponseEntity<>(cardInfoDTOs, HttpStatus.OK);
	}

	@DeleteMapping("delete")
	public ResponseEntity<Object> delete(@RequestParam("customerEmail") String customerEmail,
			@RequestParam("cardNumber") Long cardNumber) {
		cardInfoService.delete(customerEmail, cardNumber);
		return new ResponseEntity<>(HttpStatus.OK);
	}

	@ExceptionHandler
	public ResponseEntity<Object> invalidCardNumber(InvalidCardNumberException invalidCardNumberException) {
		return ResponseEntity.status(500).body(invalidCardNumberException.getMessage());
	}

	@ExceptionHandler
	public ResponseEntity<Object> expiredCard(CardAlreadyExpiredException cardAlreadyExpiredException) {
		return ResponseEntity.status(500).body(cardAlreadyExpiredException.getMessage());
	}
	
	@ExceptionHandler
	public ResponseEntity<Object> expiredCard(CardNumberNotUniqueException cardNumberNotUniqueException) {
		return ResponseEntity.status(500).body(cardNumberNotUniqueException.getMessage());
	}

}
