package com.infy.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.infy.dto.CardInfoDTO;
import com.infy.entity.CardInfo;
import com.infy.exception.CardAlreadyExpiredException;
import com.infy.exception.CardNumberNotUniqueException;
import com.infy.exception.InvalidCardNumberException;
import com.infy.repo.CardInfoRepo;

@Service
public class CardInfoServiceImpl implements CardInfoService {

	@Autowired
	CardInfoRepo cardInfoRepo;

	@Override
	public boolean add(CardInfoDTO cardInfoDTO) {
		CardInfo cardInfo = new CardInfo();
		cardInfo.setCustomerEmail(cardInfoDTO.getCustomerEmail());
		cardInfo.setCardNumber(cardInfoDTO.getCardNumber());
		cardInfo.setExpiryDate(cardInfoDTO.getExpiryDate());
		cardInfo.setName(cardInfoDTO.getName());
		if (!checkLuhn(String.valueOf(cardInfoDTO.getCardNumber()))) {
			throw new InvalidCardNumberException("Invalid card number!!");
		}
		if (validateCardExpiryDate(cardInfoDTO.getExpiryDate())) {
			throw new CardAlreadyExpiredException("Card is already expired!");
		}
		if (!isUnique(cardInfoDTO.getCustomerEmail(), cardInfoDTO.getCardNumber())) {
			throw new CardNumberNotUniqueException("Card number is not unique!!!");
		}
		cardInfoRepo.saveAndFlush(cardInfo);
		return true;
	}

	@Override
	public boolean delete(String customerEmail, Long cardNumber) {
		cardInfoRepo.deleteByCustomerEmailAndCardNumber(customerEmail, cardNumber);
		return true;
	}

	@Override
	public List<CardInfoDTO> view(String customerEmail) {
		List<CardInfo> cardInfos = cardInfoRepo.findByCustomerEmail(customerEmail);
		List<CardInfoDTO> cardInfoDTOs = new ArrayList<>();
		for (CardInfo cardInfo : cardInfos) {
			CardInfoDTO cardInfoDTO = new CardInfoDTO();
			cardInfoDTO.setCustomerEmail(cardInfo.getCustomerEmail());
			cardInfoDTO.setCardNumber(cardInfo.getCardNumber());
			cardInfoDTO.setExpiryDate(cardInfo.getExpiryDate());
			cardInfoDTO.setName(cardInfo.getName());
			cardInfoDTOs.add(cardInfoDTO);
		}
		return cardInfoDTOs;
	}

	private boolean checkLuhn(String cardNo) {
		int nDigits = cardNo.length();
		int nSum = 0;
		boolean isSecond = false;
		for (int i = nDigits - 1; i >= 0; i--) {
			int d = cardNo.charAt(i) - '0';
			if (isSecond)
				d = d * 2;
			nSum += d / 10;
			nSum += d % 10;
			isSecond = !isSecond;
		}
		return (nSum % 10 == 0);
	}

	private boolean validateCardExpiryDate(String expiryDate) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/yy");
		simpleDateFormat.setLenient(false);
		Date expiry = null;
		try {
			expiry = simpleDateFormat.parse(expiryDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return expiry.before(new Date());
	}

	private boolean isUnique(String customerEmail, Long cardNumber) {
		List<CardInfo> cardInfos = cardInfoRepo.findByCustomerEmail(customerEmail);
		for (CardInfo cardInfo : cardInfos) {
			if (cardNumber.equals(cardInfo.getCardNumber())) {
				return false;
			}
		}
		return true;
	}

}
